#
#----------------------------------------------
#
#  THE LEGEND OF CTEC
#
# By: Isobel Lennox
#
# March 2014
#
#-------------------MUSIC---------------------------
#


import pygame, sys
pygame.mixer.music.load("Town2.wav")
        #pygame.mixer.music.play(0) #play once (good for sound effect)
pygame.mixer.music.play(-1) #play infinitely

