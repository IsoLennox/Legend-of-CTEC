
import subprocess

subprocess.call(['notepad.exe', 'scoreboard.txt'])